from pattern import Checker, Circle, Spectrum

if __name__ == '__main__':
    checker = Checker(100, 25)
    checker.draw()
    checker.show()